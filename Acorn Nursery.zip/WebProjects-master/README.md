# WebProjects
The Flex project was created in 2 days while the Acorn Nursery Platform is my senior project coming up to 128hrs for development time.

The Acorn project is everything in this repo minus the collin-flex which is my class room project. The Front-End branch is where I spent most of my time developing and should be the focus for evaluation on my skill set.
Acorn Nursery is currently an on going project. This is prototype 1 with our scope.
